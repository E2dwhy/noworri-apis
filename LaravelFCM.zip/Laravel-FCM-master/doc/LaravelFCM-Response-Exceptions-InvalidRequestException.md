LaravelFCM\Response\Exceptions\InvalidRequestException
===============

Class InvalidRequestException




* Class name: InvalidRequestException
* Namespace: LaravelFCM\Response\Exceptions
* Parent class: Exception







Methods
-------


### __construct

    mixed LaravelFCM\Response\Exceptions\InvalidRequestException::__construct(\GuzzleHttp\Psr7\Response $response)

InvalidRequestException constructor.



* Visibility: **public**


#### Arguments
* $response **GuzzleHttp\Psr7\Response**


