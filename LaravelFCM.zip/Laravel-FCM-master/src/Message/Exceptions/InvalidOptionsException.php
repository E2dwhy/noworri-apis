<?php

namespace LaravelFCM\Message\Exceptions;

use Exception;

/**
 * Class InvalidOptionsException.
 */
class InvalidOptionsException extends Exception
{
}
