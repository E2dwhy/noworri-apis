=== Noworri Escrow Payment Gateway ===
Contributors: E2dwhy
Tags: noworri, payment gateway, E2dwhy, plugins, verve, ghana, nigeria, south africa, naira, cedi, rand, mastercard, visa
Requires at least: 1.0
Tested up to: 1.2.0
Stable tag: 1.2.2
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Noworri will hold your purchase amount into an Escrow account and disburse it to the merchant only if
you acknowledge the reception of your items.( Highly recommended payment )


== Description ==
Noworri is the most reliable, secure, and risk-free escrow payment method used to safeguard merchants,  against counterparty risks such as unserious buyers, fake payment, dummy orders commonly associated with cash on delivery. It can be integrated into any website, marketplace, classified site, shopping cart, or mobile app with no chargebacks, ever.

Noworri is built on top of trusted and well-recognized financial institutions across Ghana and Nigeria. Making our Escrow technology scalable across different markets.

    
All Ghanaians merchants can enable their e-commerce in Nigeria to receive orders through our Escrow payment and cash out their money instantly in their local currency. Noworri reduces the shopping experience and increases the purchase rate of your customers to a single click. Meaning customers No more fill name, email, billing address, shipping address, credit card details. All it takes now is one click. 

Noworri is the safest secure escrow payment tool use by 100+ merchants across Ghana and Nigeria because it ensures both the merchant and the buyer that the money is kept safe in escrow.

* __Mastercard__
* __Visa__
* __USSD__
* __Mobile Money__
* __Bank Transfer__
* __Bank Account__

= Note =

This plugin is meant to be used by merchants in Nigeria and Ghana.

= Plugin Features =

*   __Accept payment__ via Mastercard, Visa, Verve, USSD, Mobile Money, Bank Transfer, EFT, Bank Accounts, GTB 737 & Visa QR.
*   __Seamless integration__ into the W Commerce checkout page. Accept payment directly on your site



== Installation ==

= Automatic Installation =
* 	Login to your WordPress Admin area
* 	Go to "Plugins > Add New" from the left hand menu
* 	In the search box type __Noworri Escrow Payment Gateway__
*	From the search result you will see __Noworri Escrow Payment Gateway__ click on __Install Now__ to install the plugin
*	A popup window will ask you to confirm your wish to install the Plugin.
*	After installation, activate the plugin.
* 	Open the settings page for Woo Commerce and click the "Checkout" tab.
* 	Click on the __Noworri__ link from the available Checkout Options
*	Configure your __Noworri Payment Gateway__ settings. See below for details.

= Manual Installation =
1. 	Download the plugin zip file
2. 	Login to your WordPress Admin. Click on "Plugins > Add New" from the left hand menu.
3.  Click on the "Upload" option, then click "Choose File" to select the zip file from your computer. Once selected, press "OK" and press the "Install Now" button.
4.  Activate the plugin.
5. 	Open the settings page for Woo Commerce and click the "Checkout" tab.
6. 	Click on the __Noworri__ link from the available Checkout Options
7.	Configure your __Noworri Payment Gateway__ settings. See below for details.



= Configure the plugin =
To configure the plugin, go to __Woo Commerce > Settings__ from the left hand menu, then click __Checkout__ from the top tab. You will see __Noworri__ as part of the available Checkout Options. Click on it to configure the payment gateway.

* __Enable/Disable__ - check the box to enable Noworri Payment Gateway.
* __Title__ - allows you to determine what your customers will see this payment option as on the checkout page.
* __Description__ - controls the message that appears under the payment fields on the checkout page. Here you can list the types of cards you accept.
* __Test Mode__ - Check to enable test mode. Test mode enables you to test payments before going live. If you ready to start receving real payment on your site, kindly uncheck this.
* __Test Secret Key__ - Enter your Test Secret Key here. Get your API keys from your Noworri account under Settings > Developer/API
* __Live Secret Key__ - Enter your Live Secret Key here. Get your API keys from your Noworri account under Settings > Developer/API
* Click on __Save Changes__ for the changes you made to be effected.





== Frequently Asked Questions ==

= What Do I Need To Use The Plugin =

1.	You need to have Woo Commerce plugin installed and activated on your WordPress site.
2.	You need to open a Noworri merchant account on [Noworri](https://web.noworri.com)

== Changelog ==
= 1.2.2 - Monday 24, 2021 =
*	Fix: Make titleand description settings readonly

= 1.2.1 - Friday 21, 2021 =
*	Fix: Implement order status update

= 1.2.0 - Thursday 20, 2021 =
*   Feat: process Payments with noworri

= 1.0.0 - Wednesday 19, 2021 =
*   First release



== Upgrade Notice ==


== Screenshots ==

1. Noworri Escrow Payment Gateway Setting Page

2. Noworri Escrow Payment Gateway on the checkout page

3. Noworri payment page