<?php

/**
 * Plugin Name: Noworri Escrow Payment Gateway
 * Plugin URI: https://noworri.com/docs
 * Description: Noworri Escrow payment for Woocommerce
 * Version: 1.2.2
 * Author: Noworri
 * Author URI: https://noworri.com
 * Developer: Yoann Eddy
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * WC requires at least: 3.0.0
 * WC tested up to: 5.1
 * Text Domain: woo-noworri
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
	exit;
}

define('WC_NOWORRI_MAIN_FILE', __FILE__);
define('WC_NOWORRI_URL', untrailingslashit(plugins_url('/', __FILE__)));

define('WC_NOWORRI_VERSION', '1.2.2');

/**
 * Initialize Noworri WooCommerce Escrow payment gateway.
 */
function tbz_wc_noworri_init()
{

	load_plugin_textdomain('woo-noworri', false, plugin_basename(dirname(__FILE__)) . '/languages');
	if (!class_exists('WC_Payment_Gateway')) {
		add_action('admin_notices', 'tbz_wc_noworri_wc_missing_notice');
		return;
	}

	add_action('admin_notices', 'tbz_wc_noworri_testmode_notice');

	require_once dirname(__FILE__) . '/includes/class-wc-gateway-noworri.php';

	add_filter('woocommerce_payment_gateways', 'tbz_wc_add_noworri_gateway', 99);

	add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'tbz_woo_noworri_plugin_action_links');
}
add_action('plugins_loaded', 'tbz_wc_noworri_init', 99);

/**
 * Add Settings link to the plugin entry in the plugins menu.
 *
 * @param array $links Plugin action links.
 *
 * @return array
 **/
function tbz_woo_noworri_plugin_action_links($links)
{

	$settings_link = array(
		'settings' => '<a href="' . admin_url('admin.php?page=wc-settings&tab=checkout&section=noworri') . '" title="' . __('View Noworri WooCommerce Settings', 'woo-noworri') . '">' . __('Settings', 'woo-noworri') . '</a>',
	);

	return array_merge($settings_link, $links);
}

/**
 * Add Noworri Gateway to WooCommerce.
 *
 * @param array $methods WooCommerce payment gateways methods.
 *
 * @return array
 */
function tbz_wc_add_noworri_gateway($methods)
{

	if (class_exists('WC_Subscriptions_Order') && class_exists('WC_Payment_Gateway_CC')) {
		$methods[] = 'WC_Gateway_Noworri_Subscriptions';
	} else {
		$methods[] = 'WC_Gateway_Noworri';
	}

	if ('NGN' === get_woocommerce_currency()) {

		$settings        = get_option('woocommerce_noworri_settings', '');
		$custom_gateways = isset($settings['custom_gateways']) ? $settings['custom_gateways'] : '';
	}

	return $methods;
}

/**
 * Display a notice if WooCommerce is not installed
 */
function tbz_wc_noworri_wc_missing_notice()
{
	echo '<div class="error"><p><strong>' . sprintf(__('Noworri requires WooCommerce to be installed and active. Click %s to install WooCommerce.', 'woo-noworri'), '<a href="' . admin_url('plugin-install.php?tab=plugin-information&plugin=woocommerce&TB_iframe=true&width=772&height=539') . '" class="thickbox open-plugin-details-modal">here</a>') . '</strong></p></div>';
}

/**
 * Display the test mode notice.
 **/
function tbz_wc_noworri_testmode_notice()
{

	if (!current_user_can('manage_options')) {
		return;
	}

	$noworri_settings = get_option('woocommerce_noworri_settings');
	$test_mode         = isset($noworri_settings['testmode']) ? $noworri_settings['testmode'] : '';

	if ('yes' === $test_mode) {
		/* translators: 1. Noworri settings page URL link. */
		echo '<div class="error"><p>' . sprintf(__('Noworri test mode is still enabled, Click <strong><a href="%s">here</a></strong> to disable it when you want to start accepting live payment on your site.', 'woo-noworri'), esc_url(admin_url('admin.php?page=wc-settings&tab=checkout&section=noworri'))) . '</p></div>';
	}
}
